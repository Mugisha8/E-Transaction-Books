-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 24, 2023 at 09:50 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `accounting`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `aid` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`aid`, `name`, `type`) VALUES
(27, 'Cash', 'Asset'),
(28, 'Capital', 'Equity'),
(29, 'Bank', 'Asset'),
(30, 'Loan', 'Liability'),
(31, 'Rent', 'Expense'),
(33, 'Electricity', 'Expense'),
(34, 'Tax', 'Expense'),
(35, 'Sales income', 'Incame'),
(36, 'Interest Income', 'Incame'),
(38, 'Rental income', 'Incame');

-- --------------------------------------------------------

--
-- Table structure for table `jurnal`
--

CREATE TABLE `jurnal` (
  `id` int(11) NOT NULL,
  `aid` int(11) NOT NULL,
  `debit` int(11) NOT NULL,
  `credit` int(11) NOT NULL,
  `date` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jurnal`
--

INSERT INTO `jurnal` (`id`, `aid`, `debit`, `credit`, `date`) VALUES
(1, 1, 100, 0, '07/10/23'),
(2, 2, 0, 100, '07/10/23'),
(3, 1, 10, 0, '07/10/23'),
(4, 2, 0, 10, '07/10/23'),
(5, 1, 0, 30, '07/10/23'),
(6, 2, 30, 0, '07/10/23'),
(7, 1, 1000, 0, '07/10/23'),
(8, 3, 0, 1000, '07/10/23'),
(9, 4, 0, 200, '07/10/23'),
(10, 2, 200, 0, '07/10/23'),
(11, 5, 50, 0, '07/10/23'),
(12, 2, 0, 50, '07/10/23'),
(13, 8, 1000000, 0, '07/22/23'),
(14, 3, 0, 1000000, '07/22/23'),
(15, 5, 20000, 0, '07/22/23'),
(16, 8, 0, 20000, '07/22/23'),
(17, 17, 10000, 0, '07/23/23'),
(18, 15, 0, 10000, '07/23/23'),
(19, 25, 10000, 0, '07/23/23'),
(20, 21, 0, 10000, '07/23/23'),
(21, 20, 10000, 0, '07/23/23'),
(22, 22, 0, 10000, '07/23/23');

-- --------------------------------------------------------

--
-- Table structure for table `ledger`
--

CREATE TABLE `ledger` (
  `id` int(11) NOT NULL,
  `aid` int(11) NOT NULL,
  `debit` int(11) NOT NULL,
  `credit` int(11) NOT NULL,
  `balance` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ledger`
--

INSERT INTO `ledger` (`id`, `aid`, `debit`, `credit`, `balance`) VALUES
(1, 1, 1110, 30, 1080),
(2, 2, 230, 160, 70),
(3, 3, 0, 1001000, 1001000),
(4, 4, 0, 200, 200),
(5, 5, 20050, 0, 20050),
(6, 6, 0, 0, 0),
(7, 7, 0, 0, 0),
(8, 8, 1000000, 20000, 980000),
(9, 15, 0, 10000, 10000),
(10, 16, 0, 0, 0),
(11, 17, 10000, 0, 10000),
(12, 18, 0, 0, 0),
(13, 19, 0, 0, 0),
(14, 20, 10000, 0, 10000),
(15, 21, 0, 10000, 10000),
(16, 22, 0, 10000, 10000),
(17, 23, 0, 0, 0),
(18, 24, 0, 0, 0),
(19, 25, 10000, 0, 10000),
(20, 26, 0, 0, 0),
(21, 27, 0, 0, 0),
(22, 28, 0, 0, 0),
(23, 29, 0, 0, 0),
(24, 30, 0, 0, 0),
(25, 31, 0, 0, 0),
(26, 32, 0, 0, 0),
(27, 33, 0, 0, 0),
(28, 34, 0, 0, 0),
(29, 35, 0, 0, 0),
(30, 36, 0, 0, 0),
(31, 37, 0, 0, 0),
(32, 38, 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `jurnal`
--
ALTER TABLE `jurnal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ledger`
--
ALTER TABLE `ledger`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `jurnal`
--
ALTER TABLE `jurnal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `ledger`
--
ALTER TABLE `ledger`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
